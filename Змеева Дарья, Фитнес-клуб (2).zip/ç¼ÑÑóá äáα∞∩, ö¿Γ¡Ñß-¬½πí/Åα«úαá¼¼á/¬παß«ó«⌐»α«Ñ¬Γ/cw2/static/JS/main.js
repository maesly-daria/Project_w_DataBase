'use strict';

/*// -------objectFitImages
window.objectFitImages();


 --------imask
var imask = window.IMask;

imask(document.getElementById('form-tel'), {
  mask: '+{7}(000)000-00-00',
});*/


// -----toggler
var subscriptions = document.querySelector('.subscriptions');
var togglers = subscriptions.querySelectorAll('.subscriptions__toggler-item');
var subscriptionsLists = subscriptions.querySelectorAll('.subscriptions__list');

var activeScreen = 0;

var addActiveClass = function () {
  for (var i = 0; i < togglers.length; i += 1) {
    if (i === activeScreen) {
      subscriptionsLists[i].querySelector('.subscriptions__item').classList.add('subscriptions__item--active');
      togglers[i].classList.add('subscriptions__toggler-item--active');
    }
  }
};

var removeActiveClass = function () {
  for (var i = 0; i < togglers.length; i += 1) {
    if (i === activeScreen) {
      subscriptionsLists[i].classList.remove('subscriptions__list--active');
      togglers[i].classList.remove('subscriptions__toggler-item--active');
    }
  }
};

var onTogglerClick = function (e) {
  for (var i = 0; i < togglers.length; i += 1) {
    if (togglers[i] === e.target) {
      removeActiveClass();
      activeScreen = i;
      addActiveClass();
    }
  }
};

var addEventListeners = function () {
  for (var i = 0; i < togglers.length; i += 1) {
    togglers[i].addEventListener('click', onTogglerClick);
  }
};

document.addEventListener('DOMContentLoaded', function() {
  const form = document.querySelector('.form');
  const modal = document.querySelector('.modal');
  const modalMessage = document.querySelector('.modal__message');

  form.addEventListener('submit', function(event) {
    event.preventDefault();

    fetch('/', {
      method: 'POST',
      body: new FormData(form)
    })
    .then(response => response.json())
    .then(data => {
      modalMessage.textContent = data.message;
      modal.style.display = 'block';
    })
    .catch(error => {
      console.error('Error:', error);
    });
  });

  modal.addEventListener('click', function(event) {
    if (event.target === modal) {
      modal.style.display = 'none';
    }
  });
});

addActiveClass();
addEventListeners();