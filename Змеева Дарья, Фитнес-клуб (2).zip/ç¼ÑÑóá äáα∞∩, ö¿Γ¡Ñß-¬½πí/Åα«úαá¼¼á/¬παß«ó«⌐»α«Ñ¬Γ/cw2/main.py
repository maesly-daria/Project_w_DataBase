from flask import Flask, redirect, render_template, request, url_for, jsonify
import psycopg2
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)


def get_db_connection():
    conn = psycopg2.connect(host='localhost',
                            database='Fitness',
                            user='postgres',
                            password='admin')
    return conn

'''sub'''

@app.route('/adminsub', methods=['GET']) #
def adminsub(): #
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('SELECT * FROM subscription ORDER BY subscription_id ASC;') #
    data = cur.fetchall()
    sub = []
    for d in data:
        sub.append({ #
            'id': d[0],
            'type': d[1],
            'price': d[2]
        })
    cur.close()
    conn.close()
    return render_template('admin/tablesub.html', data = sub) #

@app.route('/addsub/', methods=['POST']) #
def add_sub(): #
    conn = get_db_connection()
    cur = conn.cursor()
    type = request.form['type'] #
    price = request.form['price'] #
    cur.execute(f"INSERT INTO subscription (type, price) VALUES ('{type}', {price})") #
    conn.commit()
    cur.close()
    conn.close()
    return jsonify({'status': 'success'})
    
@app.route('/deletesub/<int:id>', methods=['POST']) #
def delete_sub(id): #
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute(f'DELETE FROM subscription WHERE subscription_id = {id}') #
    conn.commit()
    cur.close()
    conn.close()
    return jsonify({'status': 'success'})

@app.route('/sub/<int:id>', methods=['GET', 'POST']) #
def edit_sub(id):#
    conn = get_db_connection()
    cur = conn.cursor()

    if request.method == 'GET':
        cur.execute(f'SELECT * FROM subscription WHERE subscription_id = {id};') #
        data = cur.fetchone()
        cur.close()
        conn.close()
        return jsonify({'id': data[0], 'type': data[1], 'price': data[2]}) #
    
    elif request.method == 'POST':
        type = request.form['type'] #
        price = request.form['price'] #
        cur.execute("UPDATE subscription SET type = %s, price = %s WHERE subscription_id = %s", (type, price, id)) #
        conn.commit()
        cur.close()
        conn.close()
        return jsonify({'status': 'success'})

'''///'''

@app.route('/adminhall', methods=['GET']) #
def adminhall(): #
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('SELECT * FROM hall ORDER BY hall_id ASC;') #
    data = cur.fetchall()
    hall = []
    for d in data:
        hall.append({ #
            'id': d[0],
            'name_hall': d[1],
            'address': d[2],
            'opening_hours': d[3]
        })
    cur.close()
    conn.close()
    return render_template('admin/tablehall.html', data = hall) #

@app.route('/addhall/', methods=['POST']) #
def add_hall():
    conn = get_db_connection()
    cur = conn.cursor()
    name_hall = request.form['name_hall']
    address = request.form['address']
    opening_hours = request.form['opening_hours']
    cur.execute(f"INSERT INTO hall (name_hall, address, opening_hours) VALUES ('{name_hall}', {address}, {opening_hours})")
    conn.commit()
    cur.close()
    conn.close()
    return jsonify({'status': 'success'})

@app.route('/deletehall/<int:id>', methods=['POST']) #
def delete_hall(id): #
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute(f'DELETE FROM hall WHERE hall_id = {id}') #
    conn.commit()
    cur.close()
    conn.close()
    return jsonify({'status': 'success'})
   
@app.route('/hall/<int:id>', methods=['GET', 'POST']) #
def edit_hall(id):#
    conn = get_db_connection()
    cur = conn.cursor()

    if request.method == 'GET':
        cur.execute(f'SELECT * FROM hall WHERE hall_id = {id};') #
        data = cur.fetchone()
        cur.close()
        conn.close()
        return jsonify({'id': data[0], 'name_hall': data[1], 'address': data[2], 'opening_hours': data[3]}) #
    
    elif request.method == 'POST':
        name_hall = request.form['name_hall'] #
        address = request.form['address'] #
        opening_hours = request.form['opening_hours'] #
        cur.execute("UPDATE hall SET name_hall = %s, address = %s, opening_hours = %s WHERE hall_id = %s", (name_hall, address, opening_hours, id)) #
        conn.commit()
        cur.close()
        conn.close()
        return jsonify({'status': 'success'})
    
'''//////////////////////////////////////////'''

'''tr'''

@app.route('/admintrainer', methods=['GET']) #
def admintrainer(): #
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('SELECT trainer_id, name_trainer, name_hall, specialization, experience, schedule_work, phone_number, email FROM trainer JOIN hall ON hall.hall_id = trainer.hall_id ORDER BY trainer_id') #
    data = cur.fetchall()
    trainer = []
    for d in data:
        trainer.append({ #
            'id': d[0],
            'name_trainer': d[1],
            'name_hall': d[2],
            'specialization': d[3],
            'experience': d[4],
            'schedule_work': d[5],
            'phone_number': d[6],
            'email': d[7]
        })
    cur.close()
    conn.close()
    return render_template('admin/tabletrainer.html', data = trainer) #
''''''
@app.route('/addtrainer/', methods=['POST']) #
def add_trainer():
    conn = get_db_connection()
    cur = conn.cursor()
    name_trainer = request.form['name_trainer'] #
    name_hall = request.form['name_hall'] #
    specialization = request.form['specialization'] #
    experience = int(request.form['experience'])
    schedule_work = request.form['schedule_work'] #
    phone_number = request.form['phone_number'] #
    email = request.form['email'] #
    cur.execute(f"SELECT hall_id FROM hall WHERE name_hall = '{name_hall}'")
    data = cur.fetchone()
    cur.execute(f"INSERT INTO trainer (name_trainer, hall_id, specialization, experience, schedule_work, phone_number, email) VALUES ('{name_trainer}', '{data[0]}', '{specialization}', '{experience}', '{schedule_work}', '{phone_number}', '{email}')")
    conn.commit()
    cur.close()
    conn.close()
    return jsonify({'status': 'success'})

@app.route('/deletetrainer/<int:id>', methods=['POST']) #
def delete_trainer(id): #
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute(f'DELETE FROM trainer WHERE trainer_id = {id}') #
    conn.commit()
    cur.close()
    conn.close()
    return jsonify({'status': 'success'})
   
@app.route('/trainer/<int:id>', methods=['GET', 'POST']) #
def edit_trainer(id):#
    conn = get_db_connection()
    cur = conn.cursor()

    if request.method == 'GET':
        cur.execute(f'SELECT trainer_id, name_trainer, name_hall, specialization, experience, schedule_work, phone_number, email FROM trainer JOIN hall ON hall.hall_id = trainer.hall_id WHERE trainer_id = {id} ORDER BY trainer_id;') #
        data = cur.fetchone()
        cur.close()
        conn.close()
        return jsonify({'id': data[0], 'name_trainer': data[1], 'name_hall': data[2], 'specialization': data[3], 'experience': data[4], 'schedule_work': data[5], 'phone_number': data[6], 'email': data[7]}) #
    
    elif request.method == 'POST':
        name_trainer = request.form['name_trainer'] #
        name_hall = request.form['name_hall'] #
        specialization = request.form['specialization'] #
        experience = request.form['experience'] #
        schedule_work = request.form['schedule_work'] #
        phone_number = request.form['phone_number'] #
        email = request.form['email'] #
        cur.execute(f"SELECT hall_id FROM hall WHERE name_hall = '{name_hall}'")
        data = cur.fetchone()
        cur.execute("UPDATE trainer SET name_trainer = %s, hall_id = %s, specialization = %s, experience = %s, schedule_work = %s, phone_number = %s, email = %s WHERE trainer_id = %s", (name_trainer, data[0], specialization, experience, schedule_work, phone_number, email, id)) #
        conn.commit()
        cur.close()
        conn.close()
        print(experience)
        return jsonify({'status': 'success'})
    
'''///'''
'''work'''

@app.route('/adminwork', methods=['GET']) #
def adminwork(): #
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('SELECT workout_id, type, name_hall, name_trainer, difficulty_level, duration, day, LEFT(CAST(time AS VARCHAR(10)), 5), index_day, current_capacity, max_capacity FROM public.workout JOIN hall ON hall.hall_id = workout.hall_id JOIN trainer ON trainer.trainer_id = workout.trainer_id ORDER BY workout_id;') #
    data = cur.fetchall()
    work = []
    for d in data:
        work.append({ #
            'id': d[0],
            'type': d[1],
            'name_hall': d[2],
            'name_trainer': d[3],
            'difficulty_level': d[4],
            'duration': d[5],
            'day': d[6],
            'time': d[7],
            'index_day': d[8],
            'current_capacity': d[9],
            'max_capacity': d[10]
        })
    cur.close()
    conn.close()
    return render_template('admin/tablework.html', data = work) #

@app.route('/addwork/', methods=['POST']) #
def add_work():
    conn = get_db_connection()
    cur = conn.cursor()
    type = request.form['type']
    name_hall = request.form['name_hall']
    name_trainer = request.form['name_trainer']
    difficulty_level = int(request.form['difficulty_level'])
    duration = request.form['duration']
    day = request.form['day']
    time = request.form['time']
    index_day = request.form['index_day']
    current_capacity = request.form['current_capacity']
    max_capacity = request.form['max_capacity']
    
    cur.execute(f"SELECT hall_id FROM hall WHERE name_hall = '{name_hall}'")
    data1 = cur.fetchone()
    cur.execute(f"SELECT trainer_id FROM trainer WHERE name_trainer = '{name_trainer}'")
    data2 = cur.fetchone()
    cur.execute(f"INSERT INTO workout (type, hall_id, trainer_id, difficulty_level, duration, day, time, index_day, current_capacity, max_capacity) VALUES ('{type}', '{data1[0]}', '{data2[0]}', '{difficulty_level}', '{duration}', '{day}', '{time}', '{index_day}', '{current_capacity}', '{max_capacity}')")
    conn.commit()
    cur.close()
    conn.close()
    return jsonify({'status': 'success'})

@app.route('/deletework/<int:id>', methods=['POST']) #
def delete_work(id): #
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute(f'DELETE FROM workout WHERE workout_id = {id}') #
    conn.commit()
    cur.close()
    conn.close()
    return jsonify({'status': 'success'})
   
@app.route('/work/<int:id>', methods=['GET', 'POST']) #
def edit_work(id):#
    conn = get_db_connection()
    cur = conn.cursor()

    if request.method == 'GET':

        cur.execute(f'SELECT workout_id, type, name_hall, name_trainer, difficulty_level, duration, day, time, index_day, current_capacity, max_capacity FROM public.workout JOIN hall ON hall.hall_id = workout.hall_id JOIN trainer ON trainer.trainer_id = workout.trainer_id WHERE workout_id = {id};') #
        data = cur.fetchone()
        cur.close()
        conn.close()
        return jsonify({'id': data[0], 'type': data[1], 'name_hall': data[2], 'name_trainer': data[3], 'difficulty_level': data[4], 'duration': data[5], 'day': data[6], 'time': data[7].strftime("%H:%M"), 'index_day': data[8], 'current_capacity': data[9], 'max_capacity': data[10]}) #
    
    elif request.method == 'POST':
        type = request.form['type']
        name_hall = request.form['name_hall']
        name_trainer = request.form['name_trainer']
        difficulty_level = request.form['difficulty_level']
        duration = request.form['duration']
        day = request.form['day']
        time = request.form['time']
        index_day = request.form['index_day']
        current_capacity = request.form['current_capacity']
        max_capacity = request.form['max_capacity']
        cur.execute(f"SELECT hall_id FROM hall WHERE name_hall = '{name_hall}'")
        data1 = cur.fetchone()
        cur.execute(f"SELECT trainer_id FROM trainer WHERE name_trainer = '{name_trainer}'")
        data2 = cur.fetchone()
        cur.execute("UPDATE workout SET type = %s, hall_id = %s, trainer_id = %s, difficulty_level = %s, duration = %s, day = %s, time = %s, index_day = %s, current_capacity = %s, max_capacity = %s WHERE workout_id = %s", (type, data1, data2, difficulty_level, duration, day, time, index_day, current_capacity, max_capacity, id)) #
        conn.commit()
        cur.close()
        conn.close()
        return jsonify({'status': 'success'})
    
'''////////////////////////////////////////////////'''

'''client'''

@app.route('/adminclient', methods=['GET']) #
def adminclient(): #
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT client.client_id, client.name_client, client.gender, client.age, client.phone_number, client.email, hall.name_hall, subscription.type, to_char(client.sub_start, 'DD.MM.YY') as sub_start, string_agg(cast(client_workout.workout as text), ', ' ORDER BY client_workout.workout) AS workouts FROM client LEFT JOIN hall ON client.hall_id = hall.hall_id LEFT JOIN subscription ON client.subscription_id = subscription.subscription_id LEFT JOIN client_workout ON client.client_id = client_workout.client GROUP BY client.client_id, client.name_client, client.gender, client.age, client.phone_number, client.email, hall.name_hall, subscription.type, to_char(client.sub_start, 'DD.MM.YY') ORDER BY client.client_id;")
    data = cur.fetchall()##############################################################################################################3
    client = []
    for d in data:
        client.append({ #
            'id': d[0],
            'name_client': d[1],
            'gender': d[2],
            'age': d[3],
            'phone_number': d[4],
            'email': d[5],
            'hall_id': d[6],
            'subscription_id': d[7],
            'sub_start': d[8],
            'sub_workout': d[9]
        })
    cur.close()
    conn.close()
    return render_template('admin/tableclient.html', data = client) #

@app.route('/addclient/', methods=['POST']) #
def add_client():
    conn = get_db_connection()
    cur = conn.cursor()
    name_client = request.form['name_client'] #
    gender = request.form['gender']
    age = request.form['age']
    phone_number = request.form['phone_number']
    email = request.form['email']
    name_hall = request.form['name_hall']
    type = request.form['type']
    sub_start = request.form['sub_start'] 
    #########################################################################################
    cur.execute(f"SELECT hall_id FROM hall WHERE name_hall = '{name_hall}'")
    data1 = cur.fetchone()
    cur.execute(f"SELECT subscription_id FROM subscription WHERE type = '{type}'")
    data2 = cur.fetchone()
    print(data2[0])
    '''cur.execute(f"SELECT client_workout.workout FROM client_workout WHERE client_workout.client IN (SELECT client FROM client_workout GROUP BY client HAVING string_agg(cast(client_workout.workout as text), ', ', ORDER BY client_workout.workout) = '{workouts}')")
    data3 = cur.fetchone()'''

    cur.execute(f"INSERT INTO client (name_client, gender, age, phone_number, email, hall_id, subscription_id, sub_start) VALUES ('{name_client}', '{gender}', '{age}', '{phone_number}', '{email}', '{data1[0]}', '{data2[0]}', '{sub_start}')")
    conn.commit()
    cur.close()
    conn.close()
    return jsonify({'status': 'success'})
    #########################################################################################
@app.route('/deleteclient/<int:id>', methods=['POST']) #
def delete_client(id): #
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute(f'DELETE FROM client WHERE client_id = {id}') #
    conn.commit()
    cur.close()
    conn.close()
    return jsonify({'status': 'success'})
   
@app.route('/client/<int:id>', methods=['GET', 'POST']) #
def edit_client(id):#
    conn = get_db_connection()
    cur = conn.cursor()
    #########################################################################################
    '''изменить'''
    #########################################################################################
    if request.method == 'GET':
        cur.execute(f'SELECT client.client_id, client.name_client, client.gender, client.age, client.phone_number, client.email, hall.name_hall, subscription.type, client.sub_start FROM client LEFT JOIN hall ON client.hall_id = hall.hall_id LEFT JOIN subscription ON client.subscription_id = subscription.subscription_id WHERE client_id = {id} ORDER BY client.client_id;')
        data = cur.fetchone()
        cur.close()
        conn.close()
        return jsonify({'id': data[0], 'name_client': data[1], 'gender': data[2], 'age': data[3], 'phone_number': data[4], 'email': data[5], 'name_hall': data[6], 'type': data[7], 'sub_start': data[8].strftime("%d.%m.%Y")}) #
    
    elif request.method == 'POST':
        name_client = request.form['name_client']
        gender = request.form['gender'] 
        age = request.form['age'] #
        phone_number = request.form['phone_number'] #
        email = request.form['email'] #
        name_hall = request.form['name_hall'] #
        type = request.form['type'] #
        sub_start = request.form['sub_start'] #
        cur.execute(f"SELECT hall_id FROM hall WHERE name_hall = '{name_hall}'")
        data1 = cur.fetchone()
        cur.execute(f"SELECT subscription_id FROM subscription WHERE type = '{type}'")
        data2 = cur.fetchone()
        cur.execute("UPDATE client SET name_client = %s, gender = %s, age = %s, phone_number = %s, email = %s, hall_id = %s, subscription_id = %s, sub_start = %s WHERE client_id = %s", (name_client, gender, age, phone_number, email, data1[0], data2[0], sub_start, id)) #
        conn.commit()
        cur.close()
        conn.close()
        return jsonify({'status': 'success'})

'''/////////////////////////////////////////////////////////////////////////////////////////////////////'''

@app.route('/account', methods=['GET'])
def account_get():
    return render_template('account.html')

@app.route('/account', methods=['POST'])
def account_post():
    phone_number = request.form['email']
    password = request.form['password']
    print(phone_number)
    print(password)
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('SELECT email, password, name_client, phone_number FROM client;')
    data = cur.fetchall()
    print(data)
    for info in data:
        if info[0] == phone_number:
            if check_password_hash(info[1], password):
                return redirect(url_for('authentification', email=info[0], phone_number=info[3]))
            else:
                return "Пароль не верный."

    cur.close()
    conn.close()
    return 'Пользователя с таким логином не существует.'
#######################################################################################изм######################
@app.route('/sub_workout', methods=['POST'])
def sub_workout():
    work = request.form.getlist('workout_select')
    if not work:
        # обработка ошибки, если пользователь не выбрал ни одной тренировки
        return "No workouts selected", 400
    email = request.form.get('email')
    conn = get_db_connection()
    cur = conn.cursor()
    # Получаем subscription_id для данного клиента
    cur.execute("SELECT subscription_id FROM client WHERE email = %s", (email,))
    subscription_id = cur.fetchone()[0]
    if subscription_id is None:
        # Если у клиента нет абонемента, возвращаем сообщение об ошибке
        return "No subscription found for this client", 400
    # Проверяем, действует ли абонемент с этим subscription_id
    cur.execute("SELECT COUNT(*) FROM subscription WHERE subscription_id = %s AND is_active = true", (subscription_id,))
    if cur.fetchone()[0] == 0:
        # Если абонемент не действует, возвращаем сообщение об ошибке
        return "Subscription is not active", 400
    client_id = None
    # Получаем client_id для данного клиента
    cur.execute("SELECT client_id FROM client WHERE email = %s", (email,))
    client_id = cur.fetchone()[0]
    for w in work:
        # Проверяем, есть ли уже запись в таблице client_workout для данного клиента и тренировки
        cur.execute("SELECT COUNT(*) FROM client_workout WHERE client_id = %s AND workout_id = %s", (client_id, int(w)))
        if cur.fetchone()[0] == 0:
            # Если записи нет, добавляем ее
            cur.execute("INSERT INTO client_workout (client_id, workout_id) VALUES (%s, %s)", (client_id, int(w)))
            # Получаем текущую загруженность тренировки
            cur.execute("SELECT current_capacity FROM workout WHERE workout_id = %s", (int(w),))
            current_capacity = cur.fetchone()[0]
            # Обновляем текущую загруженность тренировки
            cur.execute("UPDATE workout SET current_capacity = %s WHERE workout_id = %s", (current_capacity + 1, int(w)))
    conn.commit()
    cur.close()
    conn.close()
    return redirect(url_for('index'))



@app.route('/authentification', methods=['GET', 'POST'])
def authentification():
    if request.method == 'GET':
        # Получаем данные пользователя из базы данных
        email = request.args.get('email')
        phone_number = request.args.get('phone_number')
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("SELECT name_client, email, phone_number, gender, age, type, sub_start, password, name_hall FROM client LEFT JOIN subscription ON subscription.subscription_id = client.subscription_id LEFT JOIN hall ON hall.hall_id = client.hall_id WHERE email = %s AND phone_number = %s ", (email, phone_number))
        data = cur.fetchone()
        cur.execute(f"SELECT workout_id, name_hall, name_trainer, type, difficulty_level, duration,  max_capacity, day, LEFT(CAST(time AS VARCHAR(10)), 5) AS time FROM workout JOIN hall ON hall.hall_id = workout.hall_id JOIN trainer ON trainer.trainer_id = workout.trainer_id WHERE current_capacity < max_capacity ORDER BY name_hall ")
        let = []
        data2 = cur.fetchall()
        for tr in data2:
            let.append({
            "workout_id": tr[0],
            "hall" : tr[1],
            "name_trainer" : tr[2],
            "type" : tr[3],
            "difficulty_level" : tr[4],
            "duration" : tr[5],
            "max_capacity" : tr[6],
            "day" : tr[7],
            "time" : tr[8],

            })

        cur.execute("SELECT client.name_client, workout.type, workout.day, LEFT(CAST(workout.time AS VARCHAR(10)), 5), trainer.name_trainer FROM client_workout JOIN workout ON workout.workout_id = client_workout.workout JOIN client ON client.client_id = client_workout.client JOIN trainer ON trainer.trainer_id = workout.trainer_id WHERE client.email = %s AND client.phone_number = %s", (email, phone_number))
        workouts = cur.fetchall()
        cur.close()
        conn.close()
        return render_template('authentification.html', email=data[1], dropbox=let, phone_number=data[2], name_client=data[0], gender=data[3], age=data[4], type=data[5], sub_start=data[6], workouts=workouts)


    if request.method == 'POST':  # Получаем новые данные пользователя из формы
        new_name = request.form['name_client']
        #new_email = request.form['email']
        #new_phone_number = request.form['phone_number']
        new_gender = request.form['gender']
        new_age = request.form['age']
        new_password = request.form['password']

        # Проверяем, что поля не пустые
        if new_name:
            # Обновляем данные пользователя в базе данных, исключая пароль, если он не был изменен
            conn = get_db_connection()
            cur = conn.cursor()
            if new_password:
                cur.execute("UPDATE client SET name_client = %s, gender = %s, age = %s, password = %s WHERE email = %s AND phone_number = %s", (new_name, new_gender, new_age, generate_password_hash(new_password), request.form['email'], request.form['phone_number']))
            else:
                cur.execute("UPDATE client SET name_client = %s, gender = %s, age = %s WHERE email = %s AND phone_number = %s", (new_name, new_gender, new_age, request.form['email'], request.form['phone_number']))
            conn.commit()
            cur.close()
            conn.close()

            # Перенаправляем пользователя на страницу с измененными данными
            return redirect(url_for('account_get'))
        else:
            # Если поля пустые, возвращаем ошибку
            return "All fields are required"

@app.route('/registration', methods=['GET'])
def registration_get():
    return render_template('registration.html')

@app.route('/registration', methods=['POST'])
def registration_post():
    name_client = request.form['name_client']
    phone_number = request.form['phone_number']
    password = request.form['password']
    email = request.form['email']
    age = request.form['age']
    print(phone_number)
    print(email)
    print(password)
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute(f"INSERT INTO client (name_client, phone_number, email, password, age) VALUES ('{name_client}', '{phone_number}', '{email}', '{generate_password_hash(password)}', '{age}') RETURNING client_id;")
    conn.commit()
    data = cur.fetchone()[0]
    print(data)

    cur.close()
    conn.close()
    return 'Авторизация прошла успешно!'

@app.route('/', methods=['GET', 'POST'])
def index():
    halls = []
    trainer = []
    workouts = []
    subscriptions = []
    conn = get_db_connection()
    cur = conn.cursor()

    cur.execute(f"SELECT hall_id, name_hall, address, opening_hours FROM hall")
    data = cur.fetchall()
    for tr in data:
        halls.append({
        "hall_id": tr[0],
        "name_hall": tr[1],
        "address" : tr[2],
        "opening_hours" : tr[3] })

    cur.execute(f"SELECT subscription_id, type, price FROM subscription")
    data = cur.fetchall()
    for tr in data:
        subscriptions.append({
        "subscriptions_id" : tr[0],
        "type" : tr[1],
        "price" : tr[2] })

    cur.execute(f"SELECT trainer_id, name_trainer, name_hall, specialization, experience, schedule_work FROM trainer JOIN hall ON hall.hall_id = trainer.hall_id ")
    data = cur.fetchall()
    for tr in data:
        trainer.append({
        "trainer_id": tr[0],
        "name_trainer": tr[1],
        "hall_id" : tr[2],
        "specialization" : tr[3],
        "experience" : tr[4],
        "schedule_work" : tr[5] })

    cur.execute(f"SELECT workout_id, name_hall, name_trainer, type, difficulty_level, duration,  max_capacity, day, LEFT(CAST(time AS VARCHAR(10)), 5) AS time FROM workout JOIN hall ON hall.hall_id = workout.hall_id JOIN trainer ON trainer.trainer_id = workout.trainer_id ORDER BY name_hall ")
    data = cur.fetchall()
    hall = {}
    for tr in data:
        if tr[1] in hall:
            hall[tr[1]].append({
                "workout_id": tr[0],
                "name_trainer" : tr[2],
                "type" : tr[3],
                "difficulty_level" : tr[4],
                "duration" : tr[5],
                "max_capacity" : tr[6],
                "day" : tr[7],
                "time" : tr[8] 
            })
        else:
            hall[tr[1]] = [{
                "workout_id": tr[0],
                "name_trainer" : tr[2],
                "type" : tr[3],
                "difficulty_level" : tr[4],
                "duration" : tr[5],
                "max_capacity" : tr[6],
                "day" : tr[7],
                "time" : tr[8] 
            }]


    cur.close()
    conn.close()
    return render_template('index.html', halls=halls, trainers=trainer, halls_w=hall, subscriptions=subscriptions)

'''''''''''''''''''''''''''sssssssssssssssssssssssssssssssssssssssssss'''''''''''''''''''''

@app.route('/ac_admin', methods=['GET'])
def ac_admin_get():
    return render_template('ac_admin.html')

@app.route('/ac_admin', methods=['POST'])
def ac_admin_post():
    login = request.form['login']
    password = request.form['password']
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('SELECT login, password FROM admin;')
    data = cur.fetchone()
    print(data)
    if login==data[0] and password==data[1]:
        return redirect(url_for('adminsub'))

    cur.close()
    conn.close()
    return 'User no'

''''''''''''''''''''''''''''''

@app.route('/admin', methods=['GET', 'POST'])
def admin():
    if request.method == 'GET':
        halls = []
    trainers = []
    workouts = []
    subscriptions = []
    clients = []
    conn = get_db_connection()
    cur = conn.cursor()

    cur.execute(f"SELECT hall_id, name_hall, address, opening_hours FROM hall ORDER BY hall_id")
    data = cur.fetchall()
    for tr in data:
        halls.append({
        "hall_id": tr[0],
        "name_hall": tr[1],
        "address" : tr[2],
        "opening_hours" : tr[3] })

    cur.execute(f"SELECT subscription_id, type, price FROM subscription ORDER BY subscription_id")
    data = cur.fetchall()
    for tr in data:
        subscriptions.append({
        "subscriptions_id" : tr[0],
        "type" : tr[1],
        "price" : tr[2] })

    cur.execute(f"SELECT trainer_id, name_trainer, name_hall, specialization, experience, schedule_work FROM trainer JOIN hall ON hall.hall_id = trainer.hall_id ORDER BY trainer_id;")
    data = cur.fetchall()
    for tr in data:
        trainers.append({
        "trainer_id": tr[0],
        "name_trainer": tr[1],
        "name_hall" : tr[2],
        "specialization" : tr[3],
        "experience" : tr[4],
        "schedule_work" : tr[5] })

    cur.execute(f"SELECT workout_id, name_hall, name_trainer, type, difficulty_level, duration,  max_capacity, day, LEFT(CAST(time AS VARCHAR(10)), 5) AS time FROM workout JOIN hall ON hall.hall_id = workout.hall_id JOIN trainer ON trainer.trainer_id = workout.trainer_id ORDER BY workout_id;")
    data = cur.fetchall()
    for tr in data:
        workouts.append({
            "workout_id": tr[0],
            "hall_id" : tr[1],
            "name_trainer" : tr[2],
            "type" : tr[3],
            "difficulty_level" : tr[4],
            "duration" : tr[5],
            "max_capacity" : tr[6],
            "day" : tr[7],
            "time" : tr[8] 
        })

    cur.execute(f"SELECT client_id, name_client, name_hall, gender, age, type, sub_start, sub_workout FROM client LEFT JOIN subscription ON subscription.subscription_id = client.subscription_id LEFT JOIN hall ON hall.hall_id = client.hall_id ORDER BY client_id;")
    data = cur.fetchall()
    for tr in data:
        clients.append({
            "client_id": tr[0],
            "name_client" : tr[1],
            "hall_id" : tr[2],
            "gender" : tr[3],
            "age" : tr[4],
            "type" : tr[5],
            "sub_start" : tr[6],
            "sub_workout" : tr[7]
        })

    cur.close()
    conn.close()
    return render_template('admin.html', halls=halls, trainers=trainers, workouts=workouts, subscriptions=subscriptions, clients=clients)





if __name__ == '__main__':
    app.run(debug=True)
